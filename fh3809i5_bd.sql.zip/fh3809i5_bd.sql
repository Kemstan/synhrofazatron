-- phpMyAdmin SQL Dump
-- version 4.4.6.1
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Май 23 2015 г., 16:33
-- Версия сервера: 5.6.23-72.1-beget-log
-- Версия PHP: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `fh3809i5_bd`
--

-- --------------------------------------------------------

--
-- Структура таблицы `artem_admin`
--
-- Создание: Мар 16 2014 г., 09:51
-- Последнее обновление: Мар 16 2014 г., 09:51
--

DROP TABLE IF EXISTS `artem_admin`;
CREATE TABLE IF NOT EXISTS `artem_admin` (
  `id` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `pass` text NOT NULL,
  `time` date NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `artem_messages`
--
-- Создание: Мар 16 2014 г., 10:32
-- Последнее обновление: Мар 16 2014 г., 10:32
--

DROP TABLE IF EXISTS `artem_messages`;
CREATE TABLE IF NOT EXISTS `artem_messages` (
  `id` int(6) NOT NULL,
  `author` varchar(9) NOT NULL,
  `poluchatel` varchar(9) NOT NULL,
  `date` date NOT NULL,
  `text` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `artem_oshibka`
--
-- Создание: Мар 16 2014 г., 10:30
-- Последнее обновление: Мар 20 2014 г., 23:15
-- Последняя проверка: Мар 20 2014 г., 23:15
--

DROP TABLE IF EXISTS `artem_oshibka`;
CREATE TABLE IF NOT EXISTS `artem_oshibka` (
  `ip` varchar(12) NOT NULL,
  `date` datetime NOT NULL,
  `col` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `artem_users`
--
-- Создание: Мар 16 2014 г., 10:55
-- Последнее обновление: Мар 20 2014 г., 23:15
-- Последняя проверка: Мар 20 2014 г., 23:15
--

DROP TABLE IF EXISTS `artem_users`;
CREATE TABLE IF NOT EXISTS `artem_users` (
  `id` int(11) NOT NULL,
  `login` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `avatar` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `activation` int(1) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `admin` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `artem_users`
--

INSERT INTO `artem_users` (`id`, `login`, `password`, `avatar`, `email`, `activation`, `date`, `admin`) VALUES
(1, 'artem', 'art912051994', 'images/no-avatar/no-avatar.jpg', 'artem.mandzuk@gmail.com', 1, '2014-03-16 14:54:10', 0),
(2, 'KARATIST', 'art912051994', 'images/no-avatar/no-avatar.jpg', 'artia.x-city@mail.ru', 1, '2014-03-16 14:56:49', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `data`
--
-- Создание: Май 22 2014 г., 23:05
--

DROP TABLE IF EXISTS `data`;
CREATE TABLE IF NOT EXISTS `data` (
  `id` int(4) NOT NULL,
  `fio` varchar(64) NOT NULL,
  `delta` varchar(200) NOT NULL,
  `push` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `data`
--

INSERT INTO `data` (`id`, `fio`, `delta`, `push`) VALUES
(1, 'Kravchuk Vadim', '159.8,206.8,390.6,323.4,187.2,134.8,121.8,180.6,132.8,257.4,220.8,180.6,222.2', '91.8,79.2,94.6,114.8,91,95.8,121.2,102.2,116,98.6,109.6,94.6,90.2,79.4'),
(3, 'Leus Svitlana', '149.8,199.6,809.2,307.4,72.4,301.2,327.6,180.2,135,189.6,293.6,140.8,180.6', '87.2,60.4,63.4,71.2,152.4,60.4,92.4,92.4,75.2,85.2,66.4,47.2,78,57.2'),
(4, 'Mandzuk Artem', '120.8,181.8,565.2,347.2,159.4,186,282.2,290.6,178.4,232.4,164.4,159.2,173.4', '66,76.4,65.6,68,62.2,68.2,84.4,76.2,65.2,56.8,74,66.4,73.2,54'),
(8, 'Galia Vakoluk', '191,232.2,659.6,375.2,93.8,497.8,380,382,242,384.8,100.4,110.8,280.8', '108.6,72.6,73.8,73.2,149.8,72.2,120,94,75,95.6,151,65.6,78.8,69.6'),
(9, 'Martynuik Ihor', '227.2,220.4,531.8,360.4,80,377.2,323.8,267,181.2,193.8,281,93.6,292.8', '80.8,105,71.4,61.8,128.2,105,115,95.8,70.6,80.2,72.8,144,105,69.6'),
(11, 'Maria Shchurska', '107.4,275.8,483,305,459.4,198,613.6,260.6,287.4,255.6,170.6,134,265.6', '95.4,77,62,50.2,96.2,79.2,53.4,67.6,66.2,80.4,94.4,34.6,63.8'),
(15, 'Kravets Daria', '190,323.8,390.8,332.4,116,467,301.8,333.6,114.6,201,186.8,147.8,118', '55.2,50.4,52.6,49.4,66.4,45.8,52.2,55,47.2,49,57,66.2,48,48.4'),
(16, 'Shatkovskiy Misha', '121.8,142.2,321.2,224.4,134,140.4,189.8,112,119,99.2,157.8,114.4,145.8', '64.6,70.6,58.2,62.2,56.4,58.8,85.6,64.6,63.2,69,68.2,64.8,63.6,59.6'),
(17, 'Leus Sveta', '248.4,313.4,456.8,330.4,78,296.8,304.2,227.6,122.2,200.6,163.8,140.6,170.6', '94.6,62.4,64.2,92,160,62.4,101.2,104.8,87.2,96.8,66.4,58.6,71,69'),
(18, 'koval sasha', '209.2,366.2,790.4,775,152,170.8,176,580,351.6,194.8,177,132.8,117.6', '102,87.8,73.6,66,77,78.2,112.8,85.4,94,82.4,87.8,64.2,108.8,77'),
(19, 'Pal Dmtr', '125,197.8,567.6,446.4,309,287.2,358.4,202.2,325.8,231,157.2,180.4,366.6', '79.8,75.2,73.6,69.8,81.8,89.2,111.6,70.8,80.8,71.4,86.6,92.2,92,86.4'),
(20, 'qwerty qwerty', '187.6,338.4,367.4,278.8,90,338,256.8,234.8,143,161.8,156.8,161.6,199.6', '109.8,122,96,81,111,122,154.8,104.6,84,81.2,99.8,96.4,92.6,107.4'),
(21, 'PIB PIB', '96.8,165.6,312.2,267.2,109.8,214.2,215.4,176.4,73.8,187,144.8,127.8,105.4', '63.4,64,55,65.4,69.2,66.8,102.2,84.2,67.8,58.2,53.2,46.6,69.4,62.6'),
(22, '', '95.4,110.4,841,256.8,121,284.2,127.4,520,330.6,206.8,195,316.2,74', '125.8,1432244002185,88.2,49.4,36,71.8,108.8,859346406590,286448798746,50.4,102.8,83,50.8,79'),
(23, 'mike bro', '371,194.2,414,241,138.2,171,173.6,183,231,163.2,151.4,130.8,146', '92.6,84.6,77.8,84.4,73.6,83.4,63,73.8,88,82.8,79.4,71.8,84.8,75.6');

-- --------------------------------------------------------

--
-- Структура таблицы `igor_user`
--
-- Создание: Мар 26 2014 г., 19:39
--

DROP TABLE IF EXISTS `igor_user`;
CREATE TABLE IF NOT EXISTS `igor_user` (
  `id` int(11) NOT NULL,
  `login` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Структура таблицы `vadim_users`
--
-- Создание: Апр 14 2014 г., 09:48
-- Последнее обновление: Май 26 2014 г., 12:35
--

DROP TABLE IF EXISTS `vadim_users`;
CREATE TABLE IF NOT EXISTS `vadim_users` (
  `id` int(64) NOT NULL,
  `login` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `block` int(1) NOT NULL,
  `limit` int(1) NOT NULL,
  `browser` varchar(64) NOT NULL DEFAULT '0',
  `resize` varchar(64) NOT NULL DEFAULT '0'
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `vadim_users`
--

INSERT INTO `vadim_users` (`id`, `login`, `password`, `block`, `limit`, `browser`, `resize`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 0, 0, '986c37480b1f1c2e443504b38b6361b4', '07769cd8d0a7d09818b2f0b018042fb7'),
(2, 'test', 'd41d8cd98f00b204e9800998ecf8427e', 0, 0, '986c37480b1f1c2e443504b38b6361b4', '07769cd8d0a7d09818b2f0b018042fb7'),
(3, 'qwerty', 'd41d8cd98f00b204e9800998ecf8427e', 0, 0, '0', '0'),
(4, 'user1', 'c4ca4238a0b923820dcc509a6f75849b', 0, 0, '986c37480b1f1c2e443504b38b6361b4', '07769cd8d0a7d09818b2f0b018042fb7'),
(5, 'user2', '99c5e07b4d5de9d18c350cdf64c5aa3d', 0, 0, '986c37480b1f1c2e443504b38b6361b4', '0'),
(6, 'user3', 'fae0b27c451c728867a567e8c1bb4e53', 0, 0, '0', '0'),
(7, 'user4', 'd41d8cd98f00b204e9800998ecf8427e', 0, 0, '0', '0'),
(8, 'user5', 'd41d8cd98f00b204e9800998ecf8427e', 1, 1, '986c37480b1f1c2e443504b38b6361b4', '07769cd8d0a7d09818b2f0b018042fb7'),
(9, 'user6', 'd41d8cd98f00b204e9800998ecf8427e', 0, 0, '986c37480b1f1c2e443504b38b6361b4', '07769cd8d0a7d09818b2f0b018042fb7'),
(10, 'user7', 'd41d8cd98f00b204e9800998ecf8427e', 0, 0, '986c37480b1f1c2e443504b38b6361b4', '07769cd8d0a7d09818b2f0b018042fb7'),
(11, 'user8', 'd41d8cd98f00b204e9800998ecf8427e', 0, 0, '986c37480b1f1c2e443504b38b6361b4', '07769cd8d0a7d09818b2f0b018042fb7');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `artem_admin`
--
ALTER TABLE `artem_admin`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `artem_messages`
--
ALTER TABLE `artem_messages`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `artem_users`
--
ALTER TABLE `artem_users`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `igor_user`
--
ALTER TABLE `igor_user`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `vadim_users`
--
ALTER TABLE `vadim_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `artem_admin`
--
ALTER TABLE `artem_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `artem_messages`
--
ALTER TABLE `artem_messages`
  MODIFY `id` int(6) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `artem_users`
--
ALTER TABLE `artem_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT для таблицы `data`
--
ALTER TABLE `data`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT для таблицы `igor_user`
--
ALTER TABLE `igor_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT для таблицы `vadim_users`
--
ALTER TABLE `vadim_users`
  MODIFY `id` int(64) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
